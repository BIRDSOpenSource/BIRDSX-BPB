int8 i;
unsigned int32 REFERENCE_1 = 0x04EC0000;
unsigned int32 REFERENCE_2 = 0x05500000;
unsigned int32 REFERENCE_3 = 0x02F80000;
unsigned int32 APRS_P2 = 0x035C0000;
unsigned int32 APRS_P3 = 0x03C00000;
unsigned int32 APRS_P4 = 0x04240000;
unsigned int32 APRS_P5 = 0x04880000;


void print_ln()
{
   fprintf(DEBUG, "\r\n");
}

void DEL_CMD_DATA()
{
    for (i = 0; i < 39; i++)
    {
        command_data[i] = 0;
    }
    return;
}

void DEL_DOWN_DATA()
{
   for (i = 0; i < 81; i++)
   {
      APRS_RESPONSE[i] = 0;
   }
   return;
}

void return_DOWN_DATA()
{
   delay_ms(50);
   for (i = 0; i < 81; i++)
   {
      fputc(APRS_RESPONSE[i], OBC);
      delay_ms(5);
   }
   return;
}

void SEND_CMD()
{
    for (i = 2; i < 11; i++)
    {
        fputc(command_data[i], APRS);
        delay_ms(5);
    }
}

void CMD_SENDBACK() 
{
   fputc(0x90, OBC);
   for (i = 0; i < 11; i++) 
   {
      fputc(command_data[i], OBC);
   }
   fputc(0x91, OBC);
}

void CMD_DEBUG() 
{
   fprintf(DEBUG, "Received command : ");

   for (i = 0; i < 11; i++) 
   {
      fprintf(DEBUG, "%X ", command_data[i]);
   }
   fprintf(DEBUG, "\r\n");
}

void CMD_DEBUG_2() {
   print_ln();
   delay_ms(5);
   for (i = 0; i < 11; i++) {
      fputc(command_data[i], DEBUG);
      delay_ms(5);
   }
   print_ln();
}

void WAIT_SEC(int8 n) {
   for (i = 0; i < n; i++) {
      delay_ms(1000);
   }
}


void SHOW_APRS_DATA() {
   for (int16 i = 0; i < 210; i++){
      fputc(APRS_RESPONSE[i], DEBUG);
      APRS_RESPONSE[i] = 0;
   }
   fprintf(DEBUG, "\r\n");
}

void DEL_APRS_DATA() {
   for (i = 0; i < 210; i++) {
      APRS_RESPONSE[i] = 0;
      APRS_DATA[i] = 0;
   }
}

void DATA_WRITE_TO_FM(unsigned int32 SECTOR, int16 num) {   
      unsigned int32 BYTE_ADDRESS = SECTOR - 1;
      
      for (int pkt = 0; pkt < num; pkt++) {
         for (int16 i = 0; i < 200; i++) {
            //GET_DATA_ONE_BYTE_FROM_APRS(); //Get one byte from APRS
            APRS_DATA[i] = APRS_Read();
            BYTE_ADDRESS = BYTE_ADDRESS + 1;
            SHARED_FM_BYTE_WRITE(BYTE_ADDRESS, APRS_DATA[i]);
            fprintf(DEBUG, "%X ", APRS_DATA[i]);
         }
         print_ln();
         //SHOW_APRS_DATA(); //debug
      }
      
      fprintf(DEBUG, "%03ld packets data was writen from %08lX to %08lX\r\n", num, SECTOR, BYTE_ADDRESS);
}

void RF_SWITCH_LOGIC(int1 V1, int1 V2, int1 V3)
{
   if(V1 == 1) output_high(PIN_D6);
   if(V1 == 0) output_low(PIN_D6);
   
   if(V2 == 1) output_high(PIN_D5);
   if(V2 == 0) output_low(PIN_D5);
   
   if(V3 == 1) output_high(PIN_D4);
   if(V3 == 0) output_low(PIN_D4);

}

void CPLD_SWITCH_LOGIC(int1 S0, int1 S1, int1 S2)
{
   if(S0 == 1) output_high(PIN_C6);
   if(S0 == 0) output_low(PIN_C6);
   
   if(S1 == 1) output_high(PIN_C7);
   if(S1 == 0) output_low(PIN_C7);
   
   if(S2 == 1) output_high(PIN_C2);
   if(S2 == 0) output_low(PIN_C2);

}

void APRS_OFFSET() {
   output_low(PIN_B3); //enable APRS
   output_low(PIN_B2); //eable APRS
   CPLD_SWITCH_LOGIC(0, 0, 0);  
   RF_SWITCH_LOGIC(0, 0, 0);
}

void TURN_ON_APRS_C() {
   output_high(PIN_B3); //enable APRS
   output_high(PIN_B2); //eable APRS
}
