#include <18F67J94.h>
#fuses NOWDT
#include <PIC18F67J94_registers.h>
#use delay(internal = 8MHz, clock = 8MHz)

#include <BIRDS-X_Mission_Boss.h>
#include <BIRDS-X_function_list.c>

void main()
{ 
    APRS_OFFSET();//All CPLD&RF-SW Logics set as 0
    
    output_high(PIN_G2); //high CS pin for SPI
    
    enable_interrupts(int_rda2);
    enable_interrupts(int_rda3);
    enable_interrupts(global)  ;
    
    fprintf(DEBUG, "Mission Boss activated\r\n");
    print_ln();
    
    while (TRUE)
    {
        GET_COMMANDS_FROM_OBC();

        if (Flag_OBC == 1) 
        {
            FLAG_OBC = 0;
            CMD_SENDBACK();//ackS to OBC
            CMD_DEBUG();//debug
        }
        
         if( command_data[10] ==  0xED )
         {
           switch(command_data[0])
           {
           
    ///////////////////////////////// APRS#R1 /////////////////////////////
               case 0xB0:
               
               CPLD_SWITCH_LOGIC(0, 0, 1); //CPLD Logic -> Ref-1
               fprintf(DEBUG,  "Connected to Ref-1 Board (APRS#R1)\r\n");
               
    
               switch (command_data[3]) //swich function
               {
               //////////////////// Digipeater //////////////////////
   
                   case 0xFF: //Turn off Digipeater mode
   
                   APRS_OFFSET();
                   fprintf(DEBUG, "Turn off command executed\r\n");
                   DEL_CMD_DATA();
   
                   break;
   
                   case 0xEE: //Turn on Digipeater mode
   
                   APRS_OFFSET(); //3.3 & 5.0V enale pins -> 0, CPLD & RF-SW Logic -> 0
                   delay_ms(5);
                   CPLD_SWITCH_LOGIC(0, 0, 1); //CPLD Logic -> Refernce-1
                   delay_ms(10);
                   if (command_data[4] == 0x0E) {
                     output_low(PIN_B2);//unenable 3.3V line
                     output_high(PIN_B3);//enable 5.0V line
                   } else if (command_data[4] == 0x1E) {
                     output_high(PIN_B2);//enable 3.3V line
                     output_high(PIN_B3);//enable 5.0V line
                   }
                   WAIT_SEC(5);
                   APRS_Flush();
                   SEND_CMD();
                   GET_DATA_OR_ACK_FROM_APRS();
                   SHOW_APRS_DATA();
                   
                   if(command_data[4] == 0x0E) {
                     fprintf(DEBUG, "DP activation command executed\r\n");
                   } else if(command_data[4] == 0x1E) {
                     fprintf(DEBUG, "SF-ward activation command executed\r\n");
                   }
                   DEL_APRS_DATA();
                   DEL_CMD_DATA();
                   
                   break;

                   case 0x0C: //Change the mission mode

                   APRS_Flush();
                   SEND_CMD();
                   GET_DATA_OR_ACK_FROM_APRS();
                   SHOW_APRS_DATA();
                   
                   if(command_data[4] == 0x0E) {
                     output_low(PIN_B2);//unenable 3.3V line
                     output_high(PIN_B3);//enable 5.0V line
                     fprintf(DEBUG, "DP activation command executed\r\n");
                   } else if(command_data[4] == 0x1E) {
                     output_high(PIN_B2);//enable 3.3V line
                     output_high(PIN_B3);//enable 5.0V line
                     fprintf(DEBUG, "SF-ward activation command executed\r\n");
                   }
                   
                   DEL_APRS_DATA();
                   DEL_CMD_DATA();
                   
                   break;

                   case 0x11: //Data Transfer
                   
//!                   DEL_APRS_DATA(); 
//!                   for (i = 0; i < 200; i++) {
//!                     fprintf(DEBUG, "%X", APRS_DATA[i]);
//!                   }
                   APRS_Flush();
                   delay_ms(10);
                   SEND_CMD();
                   delay_ms(10);
                
                   SHARED_FM_SECTOR_ERASE(REFERENCE_1,64, );
                   DATA_WRITE_TO_FM(REFERENCE_1, command_data[4]);
                   
                   fprintf(DEBUG, "Write to Flash Memory executed\r\n");
                   
                   DEL_APRS_DATA();
                   DEL_CMD_DATA();
                   
                   break;                  
   
               /////////////////// own mission //////////////////////
                   case 0x33://Sri lanka Beacon on command
                       
                   APRS_Flush();
                   SEND_CMD();
                   GET_DATA_OR_ACK_FROM_APRS();
                   SHOW_APRS_DATA();
                   fprintf(DEBUG, "Beacon turn on command executed\r\n");
                   DEL_CMD_DATA();               
                   DEL_APRS_DATA();
                   
                   break;
                   
                   case 0x88://Sri lanka Beacon off command
                  
                   APRS_Flush();
                   SEND_CMD();
                   GET_DATA_OR_ACK_FROM_APRS();
                   SHOW_APRS_DATA();
                   fprintf(DEBUG, "Beacon turn off command executed\r\n");//debug
                   DEL_CMD_DATA();
                   
                   break;
                   
                   case 0x69://erase sector
                  
                   APRS_Flush();
                   command_data[3] = 0x00;
                   SEND_CMD();
                   GET_DATA_OR_ACK_FROM_APRS();
                   SHOW_APRS_DATA();
                   fprintf(DEBUG, "Data erase from sectors command executed\r\n");//debug
                   DEL_CMD_DATA();
                   
                   break;
               }
               break;
          
    ///////////////////////////////// APRS#P1 /////////////////////////////
   
               case 0xB2://Reference-3

               RF_SWITCH_LOGIC(1, 0, 0); //RF-SW Logic -> Reference-3
               CPLD_SWITCH_LOGIC(0, 1, 1); //CPLD Logic -> Reference-3
               fprintf(DEBUG,  "Connected to Dummy Board (APRS#P1)\r\n");   
   
               switch (command_data[3]) //swich function
               {
               //////////////////// Digipeater //////////////////////
   
                   case 0xFF: //Turn off Digipeater mode
   
                   APRS_OFFSET();
                   fprintf(DEBUG, "Turn off command executed\r\n");
                   DEL_CMD_DATA();
   
                   break;
   
                   case 0xEE: //Turn on Digipeater mode
   
                   APRS_OFFSET(); //3.3 & 5.0V enale pins -> 0, CPLD & RF-SW Logic -> 0
                   delay_ms(5);
                   RF_SWITCH_LOGIC(1, 0, 0); //RF-SW Logic -> Reference-3
                   delay_ms(5);
                   CPLD_SWITCH_LOGIC(0, 1, 1); //CPLD Logic -> Refernce-3
                   delay_ms(10);
                   if (command_data[4] == 0x0E) {
                     output_low(PIN_B2);//unenable 3.3V line
                     output_high(PIN_B3);//enable 5.0V line
                   } else if (command_data[4] == 0x1E) {
                     output_high(PIN_B2);//enable 3.3V line
                     output_high(PIN_B3);//enable 5.0V line
                   }
                   WAIT_SEC(5);
                   APRS_Flush();
                   SEND_CMD();
                   GET_DATA_OR_ACK_FROM_APRS();
                   SHOW_APRS_DATA();
                   
                   if(command_data[4] == 0x0E) {
                     fprintf(DEBUG, "DP activation command executed\r\n");
                   } else if(command_data[4] == 0x1E) {
                     fprintf(DEBUG, "SF-ward activation command executed\r\n");
                   }
                   DEL_APRS_DATA();
                   DEL_CMD_DATA();
                   
                   break;

                   case 0x0C: //Change the mission mode

                   APRS_Flush();
                   SEND_CMD();
                   GET_DATA_OR_ACK_FROM_APRS();
                   SHOW_APRS_DATA();
                   
                   if(command_data[4] == 0x0E) {
                     output_low(PIN_B2);//unenable 3.3V line
                     output_high(PIN_B3);//enable 5.0V line
                     fprintf(DEBUG, "DP activation command executed\r\n");
                   } else if(command_data[4] == 0x1E) {
                     output_high(PIN_B2);//enable 3.3V line
                     output_high(PIN_B3);//enable 5.0V line
                     fprintf(DEBUG, "SF-ward activation command executed\r\n");
                   }
                   
                   DEL_APRS_DATA();
                   DEL_CMD_DATA();
                   
                   break;

                   case 0x11: //Data Transfer
                   
                   APRS_Flush();
                   delay_ms(10);
                   SEND_CMD();
                
                   SHARED_FM_SECTOR_ERASE(REFERENCE_3,64, );
                   DATA_WRITE_TO_FM(REFERENCE_3, command_data[4]);
                   
                   fprintf(DEBUG, "Write to Flash Memory executed\r\n");
                   
                   DEL_APRS_DATA();
                   DEL_CMD_DATA();
                   
                   break;                  
   
               /////////////////// own mission //////////////////////
                   case 0x33://Sri lanka Beacon on command
                       
                   APRS_Flush();
                   SEND_CMD();
                   GET_DATA_OR_ACK_FROM_APRS();
                   SHOW_APRS_DATA();
                   fprintf(DEBUG, "Beacon turn on command executed\r\n");
                   DEL_CMD_DATA();               
                   DEL_APRS_DATA();
                   
                   break;
                   
                   case 0x88://Sri lanka Beacon off command
                  
                   APRS_Flush();
                   SEND_CMD();
                   GET_DATA_OR_ACK_FROM_APRS();
                   SHOW_APRS_DATA();
                   fprintf(DEBUG, "Beacon turn off command executed\r\n");//debug
                   DEL_CMD_DATA();
                   
                   break;
                   
                   case 0x69://erase sector
                  
                   APRS_Flush();
                   command_data[3] = 0x00;
                   SEND_CMD();
                   GET_DATA_OR_ACK_FROM_APRS();
                   SHOW_APRS_DATA();
                   fprintf(DEBUG, "Data erase from sectors command executed\r\n");//debug
                   DEL_CMD_DATA();
                   
                   break;
               }
               break;
               
   ///////////////////////////////// APRS#P2 /////////////////////////////
   
               case 0xB3: // Sri Lanka2
               
               RF_SWITCH_LOGIC(0, 1, 0); //RF-SW Logic -> Sri Lanka-2
               CPLD_SWITCH_LOGIC(1, 0, 0); //CPLD Logic -> Sri Lanka-2
               fprintf(DEBUG, "Connected to Sri Lanka-2 Board (APRS#P2)\r\n");//debug
               
               switch (command_data[3]) //swich function
               {
               //////////////////// Digipeater //////////////////////
   
                   case 0xFF: //Turn off Digipeater mode
   
                   APRS_OFFSET();
                   fprintf(DEBUG, "Turn off command executed\r\n");
                   DEL_CMD_DATA();
   
                   break;
   
                   case 0xEE: //Turn on Digipeater mode
   
                   APRS_OFFSET(); //3.3 & 5.0V enale pins -> 0, CPLD & RF-SW Logic -> 0
                   delay_ms(5);
                   RF_SWITCH_LOGIC(0, 1, 0); //RF-SW Logic -> Sri Lanka-2
                   delay_ms(5);
                   CPLD_SWITCH_LOGIC(1, 0, 0); //CPLD Logic -> Sri Lanka-2
                   delay_ms(10);
                   TURN_ON_APRS_C(); //3.3 & 5.0V enale pins -> 1
                   wAIT_SEC(5);

                   APRS_Flush();
                   SEND_CMD();
                   delay_ms(250);
                   GET_DATA_OR_ACK_FROM_APRS();
                   SHOW_APRS_DATA();
                   
                   if(command_data[4] == 0x0E) {
                     fprintf(DEBUG, "DP activation command executed\r\n");
                   } else if(command_data[4] == 0x1E) {
                     fprintf(DEBUG, "SF-ward activation command executed\r\n");
                   }
                   DEL_APRS_DATA();
                   DEL_CMD_DATA();
                   
                   break;

                   case 0x0C: //Change the mission mode

                   SEND_CMD();
                   GET_DATA_OR_ACK_FROM_APRS();
                   SHOW_APRS_DATA();
                   
                   if(command_data[4] == 0x0E) {
                     fprintf(DEBUG, "DP activation command executed\r\n");
                   } else if(command_data[4] == 0x1E) {
                     fprintf(DEBUG, "SF-ward activation command executed\r\n");
                   }
                   
                   DEL_APRS_DATA();
                   DEL_CMD_DATA();
                   
                   break;

                   case 0x11: //Data Transfer
                   
                   APRS_Flush();
                   SEND_CMD();
                
                   SHARED_FM_SECTOR_ERASE(APRS_P2,64, );
                   DATA_WRITE_TO_FM(APRS_P2, command_data[4]);
                   
                   fprintf(DEBUG, "Write to Flash Memory executed\r\n");
                   
                   DEL_APRS_DATA();
                   DEL_CMD_DATA();
                   
                   break;                  
   
               /////////////////// own mission //////////////////////
                   case 0x33://Sri lanka Beacon on command
                       
                   APRS_Flush();
                   SEND_CMD();
                   GET_DATA_OR_ACK_FROM_APRS();
                   SHOW_APRS_DATA();
                   fprintf(DEBUG, "Beacon turn on command executed\r\n");
                   DEL_CMD_DATA();               
                   DEL_APRS_DATA();
                   
                   break;
                   
                   case 0x88://Sri lanka Beacon off command
                  
                   APRS_Flush();
                   SEND_CMD();
                   GET_DATA_OR_ACK_FROM_APRS();
                   SHOW_APRS_DATA();
                   fprintf(DEBUG, "Beacon turn off command executed\r\n");//debug
                   DEL_CMD_DATA();
                   
                   break;
                   
                   case 0x69://erase sector
                  
                   command_data[3] = 0x00;
                   APRS_Flush();
                   SEND_CMD();
                   GET_DATA_OR_ACK_FROM_APRS();
                   SHOW_APRS_DATA();
                   fprintf(DEBUG, "Data erase from sectors command executed\r\n");//debug
                   DEL_CMD_DATA();
                   
                   break;
               }
               break;
               
    ///////////////////////////////// APRS#P3 /////////////////////////////
   
               case 0xB4://Paragury
               
               RF_SWITCH_LOGIC(0, 0, 0); //RF-SW Logic -> Paragury
               CPLD_SWITCH_LOGIC(1, 0, 1); //CPLD Logic -> Paragury
               fprintf(DEBUG,  "Connected to Paragury Board (APRS#P3)\r\n");
   
               switch (command_data[3]) //swich function
               {
               //////////////////// Digipeater //////////////////////
   
                   case 0xFF: //Turn off Digipeater mode
   
                   APRS_OFFSET();
                   fprintf(DEBUG, "Turn off command executed\r\n");//debug
                   DEL_CMD_DATA();
   
                   break;
   
                   case 0xEE: //Turn on Digipeater mode
   
                   APRS_OFFSET(); //3.3 & 5.0V enale pins -> 0, CPLD & RF-SW Logic -> 0
                   delay_ms(10);
                   RF_SWITCH_LOGIC(0, 0, 0); //RF-SW Logic -> Paragury
                   delay_ms(5);
                   CPLD_SWITCH_LOGIC(1, 0, 1); //CPLD Logic -> Paragury
                   delay_ms(10);
                   TURN_ON_APRS_C(); //3.3 & 5.0V enale pins -> 1
                   WAIT_SEC(10);
                   GET_DATA_OR_ACK_FROM_APRS();
                   SEND_CMD();
                   GET_DATA_OR_ACK_FROM_APRS();
                   SHOW_APRS_DATA();
                   DEL_CMD_DATA();
                   fprintf(DEBUG, "DP activation command executed\r\n");//debug
                   
                   break;
                   
                   case 0x0C: //Change the mission mode

                   SEND_CMD();
                   GET_DATA_OR_ACK_FROM_APRS();
                   SHOW_APRS_DATA();
                   
                   if(command_data[9] == 0x01) {
                     fprintf(DEBUG, "DP activation command executed\r\n");
                   } else if(command_data[9] == 0x02) {
                     fprintf(DEBUG, "SF-ward activation command executed\r\n");
                   }
                   DEL_CMD_DATA();
                   
                   break;
   
                   case 0x11: //Real time downlink (1 packet)
   
                   APRS_Flush();
                   delay_ms(100);
                   SEND_CMD();
                   //WAIT_SEC(2);
                   
                   SHARED_FM_SECTOR_ERASE(APRS_P3,64, );
                   DATA_WRITE_TO_FM(APRS_P3, command_data[4]);
                   
                   fprintf(DEBUG, "Write to Flash Memory executed\r\n");
                   
                   DEL_DOWN_DATA();
                   DEL_CMD_DATA();
   
                   break;
                   
                   case 0xA7:
                   case 0xB0:
                   case 0xB1:
                   case 0xC3:
                   case 0xD0:
                   case 0xD1:
                   case 0xD2:
                   
                   APRS_Flush();
                   delay_ms(100);                   
                   SEND_CMD();
                   delay_ms(1000);
                   GET_DATA_OR_ACK_FROM_APRS();
                   SHOW_APRS_DATA();
                   
                   if (command_data[3] == 0xA7) {
                     fprintf(DEBUG, "Beacon Tx right now command executed");
                   } else if (command_data[3] == 0xB0) {
                     fprintf(DEBUG, "Set transceiver to low power mode command executed");
                   } else if (command_data[3] == 0xB1) {
                     fprintf(DEBUG, "Set transceiver to high power mode command executed");
                   } else if (command_data[3] == 0xC3) {
                     fprintf(DEBUG, "Set beacon period command executed");
                   } else if (command_data[3] == 0xD0) {
                     fprintf(DEBUG, "Restore default configuration");
                   } else if (command_data[3] == 0xD1) {
                     fprintf(DEBUG, "Set configuratoin to flash memory");
                   } else if (command_data[3] == 0xD2) {
                     fprintf(DEBUG, "Load configuration to flash memory");
                   }
                   
                   
                   DEL_APRS_DATA();
                   DEL_CMD_DATA();
                   
                   break;
               }
               break;
   
    ///////////////////////////////// APRS#P4 /////////////////////////////
   
               case 0xB5: // Sri Lanka1
              
               RF_SWITCH_LOGIC(0, 0, 1); //RF-SW Logic -> Sri Lanka-1
               CPLD_SWITCH_LOGIC(1, 1, 0); //CPLD Logic -> Sri Lanka-1
               fprintf(DEBUG,  "Connected to Sri Lanka-1 Board (APRS#P4)\r\n");
               
               switch (command_data[3]) //swich function
               {
               //////////////////// Digipeater //////////////////////
   
                   case 0xFF: //Turn off Digipeater mode
   
                   APRS_OFFSET();
                   fprintf(DEBUG, "Turn off command executed\r\n");
                   DEL_CMD_DATA();
   
                   break;
   
                   case 0xEE: //Turn on Digipeater mode
   
                   APRS_OFFSET(); //3.3 & 5.0V enale pins -> 0, CPLD & RF-SW Logic -> 0
                   delay_ms(10);
                   RF_SWITCH_LOGIC(0, 0, 1); //RF-SW Logic -> Sri Lanka-1
                   delay_ms(5);
                   CPLD_SWITCH_LOGIC(1, 1, 0); //CPLD Logic -> Sri Lanka-1
                   delay_ms(10);
                   TURN_ON_APRS_C(); //3.3 & 5.0V enale pins -> 1
                   wAIT_SEC(5);

                   APRS_Flush();
                   SEND_CMD();
                   delay_ms(250);
                   GET_DATA_OR_ACK_FROM_APRS();
                   SHOW_APRS_DATA();
                   
                   if(command_data[4] == 0x0E) {
                     fprintf(DEBUG, "DP activation command executed\r\n");
                   } else if(command_data[4] == 0x1E) {
                     fprintf(DEBUG, "SF-ward activation command executed\r\n");
                   }
                   DEL_APRS_DATA();
                   DEL_CMD_DATA();
                   
                   break;

                   case 0x0C: //Change the mission mode

                   APRS_Flush();
                   SEND_CMD();
                   GET_DATA_OR_ACK_FROM_APRS();
                   SHOW_APRS_DATA();
                   
                   if(command_data[4] == 0x0E) {
                     fprintf(DEBUG, "DP activation command executed\r\n");
                   } else if(command_data[4] == 0x1E) {
                     fprintf(DEBUG, "SF-ward activation command executed\r\n");
                   }
                   
                   DEL_APRS_DATA();
                   DEL_CMD_DATA();
                   
                   break;

                   case 0x11: //Data Transfer
                   
                   APRS_Flush();
                   SEND_CMD();
                
                   SHARED_FM_SECTOR_ERASE(APRS_P4,64, );
                   DATA_WRITE_TO_FM(APRS_P4, command_data[4]);
                   
                   fprintf(DEBUG, "Write to Flash Memory executed\r\n");
                   
                   DEL_APRS_DATA();
                   DEL_CMD_DATA();
                   
                   break;                  

               /////////////////// own mission //////////////////////
                   case 0x33://Sri lanka Beacon on command
                       
                   APRS_Flush();
                   SEND_CMD();
                   GET_DATA_OR_ACK_FROM_APRS();
                   SHOW_APRS_DATA();
                   fprintf(DEBUG, "Beacon turn on command executed\r\n");
                   DEL_CMD_DATA();               
                   DEL_APRS_DATA();
                   
                   break;
                   
                   case 0x88://Sri lanka Beacon off command
                  
                   APRS_Flush();
                   SEND_CMD();
                   GET_DATA_OR_ACK_FROM_APRS();
                   SHOW_APRS_DATA();
                   fprintf(DEBUG, "Beacon turn off command executed\r\n");//debug
                   DEL_CMD_DATA();
                   
                   break;
                   
                   case 0x69://erase sector
                  
                   command_data[3] = 0x00;
                   APRS_Flush();
                   SEND_CMD();
                   GET_DATA_OR_ACK_FROM_APRS();
                   SHOW_APRS_DATA();
                   fprintf(DEBUG, "Data erase from sectors command executed\r\n");//debug
                   DEL_CMD_DATA();
                   
                   break;
               }
               break;
                 
   ///////////////////////////////// APRS#P5 /////////////////////////////
   
               case 0xB6: //Canada
               
               RF_SWITCH_LOGIC(0, 1, 1); //RF-SW Logic -> Canada
               CPLD_SWITCH_LOGIC(1, 1, 1); //CPLD Logic -> Canada
               fprintf(DEBUG,  "Connected to Canada Board (APRS#P5)\r\n");
   
               switch (command_data[3]) //swich function
               {
               //////////////////// Digipeater //////////////////////
   
                   case 0xFF: //Turn off Digipeater mode
   
                   SEND_CMD();
                   GET_DATA_OR_ACK_FROM_APRS();
                   SHOW_APRS_DATA();
                   //WAIT_SEC(60);
                   APRS_OFFSET();
                   DEL_CMD_DATA();
                   fprintf(DEBUG, "Turn off command executed\r\n");
   
                   break;
   
                   case 0xEE: //Turn on the board
   
                   APRS_OFFSET(); //3.3 & 5.0V enale pins -> 0, CPLD & RF-SW Logic -> 0
                   delay_ms(10);
                   RF_SWITCH_LOGIC(0, 1, 1); //RF-SW Logic -> Canada
                   delay_ms(5);
                   CPLD_SWITCH_LOGIC(1, 1, 1); //CPLD Logic -> Canada
                   delay_ms(10);
                   //TURN_ON_APRS_C(); //3.3 & 5.0V enale pins -> 1
                   output_high(PIN_B3);//3.3V enable pin -> 1
                   wAIT_SEC(2);

                   APRS_Flush();
                   SEND_CMD();
                   delay_ms(250);
                   GET_DATA_OR_ACK_FROM_APRS();
                   SHOW_APRS_DATA();
                   
                   if(command_data[9] == 0x00) {
                     fprintf(DEBUG, "Activation without RF command executed\r\n");
                   } else if(command_data[9] == 0x01) {
                     fprintf(DEBUG, "DP activation command executed\r\n");
                   } else if(command_data[9] == 0x02) {
                     fprintf(DEBUG, "SF-ward activation command executed\r\n");
                   }
                   
                   DEL_APRS_DATA();
                   DEL_CMD_DATA();
                   
                   break;
                   
                   case 0x0C: //Change the mission mode

                   SEND_CMD();
                   GET_DATA_OR_ACK_FROM_APRS();
                   SHOW_APRS_DATA();
                   
                   if(command_data[9] == 0x00) {
                     fprintf(DEBUG, "Activation without RF command executed\r\n");
                   } else if(command_data[9] == 0x01) {
                     fprintf(DEBUG, "DP activation command executed\r\n");
                   } else if(command_data[9] == 0x02) {
                     fprintf(DEBUG, "SF-ward activation command executed\r\n");
                   }
                   
                   DEL_APRS_DATA();
                   DEL_CMD_DATA();
                   
                   break;
                   
                   case 0x11: //Data Transfer
                   
                   APRS_Flush();
                   delay_ms(100);
                   SEND_CMD();
                   WAIT_SEC(2);
                
                   SHARED_FM_SECTOR_ERASE(APRS_P5,64, );
                   DATA_WRITE_TO_FM(APRS_P5, command_data[9]);
                   
                   fprintf(DEBUG, "Write to Flash Memory executed\r\n");
                   
                   DEL_APRS_DATA();
                   DEL_CMD_DATA();
                   
                   break;
                   
                   case 0x20: //run self test
                   case 0x22: //beacon right now
                   case 0x23: //force reboot system
                   case 0x24: //set beacon period
                   case 0x25: //get uptime and status
                   
                   case 0x31: //set unix timestamp
                   case 0x32: //exp set ccd config
                   //case 0x33: //exp get radfet values
                   case 0x34: //exp ccd do debug convert
                   
                   case 0x92: //exit mission boss mode
                   
                   APRS_Flush();
                   delay_ms(100);                   
                   SEND_CMD();
                   delay_ms(1000);
                   GET_DATA_OR_ACK_FROM_APRS();
                   SHOW_APRS_DATA();
                   
                   if(command_data[3] == 0x20) {
                     fprintf(DEBUG, "Run self test command executed\r\n");
                   } else if(command_data[3] == 0x22) {
                     fprintf(DEBUG, "Beacon right now command executed\r\n");
                   } else if(command_data[3] == 0x23) {
                     fprintf(DEBUG, "Force reboot system command executed\r\n");
                   } else if(command_data[3] == 0x24) {
                     fprintf(DEBUG, "Set beacon period command executed\r\n");
                   } else if(command_data[3] == 0x25) {
                     fprintf(DEBUG, "Get uptime & status command executed\r\n");
                   } else if(command_data[3] == 0x31) {
                     fprintf(DEBUG, "Set unix timestamp command executed\r\n");
                   } else if(command_data[3] == 0x32) {
                     fprintf(DEBUG, "Set ccd config command executed\r\n");
                   } else if(command_data[3] == 0x33) {
                     fprintf(DEBUG, "Get radfet values command executed\r\n");
                   } else if(command_data[3] == 0x34) {
                     fprintf(DEBUG, "ccd do debug convert command executed\r\n");
                   } else if(command_data[3] == 0x92) {
                     fprintf(DEBUG, "Exit MissionBoss-mode command executed\r\n");
                   }
                   
                   DEL_APRS_DATA();
                   DEL_CMD_DATA();
                   
                   break;
                   
                   case 0x33:
                   
                   output_high(PIN_B2);//enable 5.0V lineS
                   delay_ms(100);
                   
                   
                   APRS_Flush();
                   delay_ms(100);                   
                   SEND_CMD();
                   delay_ms(1000);
                   GET_DATA_OR_ACK_FROM_APRS();
                   SHOW_APRS_DATA();
                   
                   DEL_APRS_DATA();
                   DEL_CMD_DATA();
                   
                   output_low(PIN_B2);
                   
                   break;
               }
               break;
               
   ///////////////////////////////// APRS#R2 /////////////////////////////
               
               case 0xB1: //Reference#2
               
               RF_SWITCH_LOGIC(1, 0, 1); //RF-SW Logic -> Ref-2
               CPLD_SWITCH_LOGIC(0, 1, 0);  //RF-SW Logic -> Ref-2
               fprintf(DEBUG,  "Connected to Ref-2 Board (APRS#R2)\r\n");
   
               switch (command_data[3]) //swich function
               {
               //////////////////// Digipeater //////////////////////
   
                   case 0xFF: //Turn off Digipeater mode
   
                   APRS_OFFSET();
                   fprintf(DEBUG, "Turn off command executed\r\n");
                   DEL_CMD_DATA();
   
                   break;
   
                   case 0xEE: //Turn on Digipeater mode
   
                   APRS_OFFSET(); //3.3 & 5.0V enale pins -> 0, CPLD & RF-SW Logic -> 0
                   delay_ms(5);
                   RF_SWITCH_LOGIC(1, 0, 1); //RF-SW Logic -> Reference-2
                   delay_ms(5);
                   CPLD_SWITCH_LOGIC(0, 1, 0); //CPLD Logic -> Refernce-2
                   delay_ms(10);
                   if (command_data[4] == 0x0E) {
                     output_low(PIN_B2);//unenable 3.3V line
                     output_high(PIN_B3);//enable 5.0V line
                   } else if (command_data[4] == 0x1E) {
                     output_high(PIN_B2);//enable 3.3V line
                     output_high(PIN_B3);//enable 5.0V line
                   }
                   WAIT_SEC(5);
                   APRS_Flush();
                   SEND_CMD();
                   GET_DATA_OR_ACK_FROM_APRS();
                   SHOW_APRS_DATA();
                   
                   if(command_data[4] == 0x0E) {
                     fprintf(DEBUG, "DP activation command executed\r\n");
                   } else if(command_data[4] == 0x1E) {
                     fprintf(DEBUG, "SF-ward activation command executed\r\n");
                   }
                   DEL_APRS_DATA();
                   DEL_CMD_DATA();
                   
                   break;

                   case 0x0C: //Change the mission mode

                   APRS_Flush();
                   SEND_CMD();
                   GET_DATA_OR_ACK_FROM_APRS();
                   SHOW_APRS_DATA();
                   
                   if(command_data[4] == 0x0E) {
                     output_low(PIN_B2);//unenable 3.3V line
                     output_high(PIN_B3);//enable 5.0V line
                     fprintf(DEBUG, "DP activation command executed\r\n");
                   } else if(command_data[4] == 0x1E) {
                     output_high(PIN_B2);//enable 3.3V line
                     output_high(PIN_B3);//enable 5.0V line
                     fprintf(DEBUG, "SF-ward activation command executed\r\n");
                   }
                   
                   DEL_APRS_DATA();
                   DEL_CMD_DATA();
                   
                   break;

                   case 0x11: //Data Transfer
                   
                   APRS_Flush();
                   SEND_CMD();
                
                   SHARED_FM_SECTOR_ERASE(REFERENCE_2,64, );
                   DATA_WRITE_TO_FM(REFERENCE_2, command_data[4]);
                   
                   fprintf(DEBUG, "Write to Flash Memory executed\r\n");
                   
                   DEL_APRS_DATA();
                   DEL_CMD_DATA();
                   
                   break;                  
   
               /////////////////// own mission //////////////////////
                   case 0x33://Sri lanka Beacon on command
                       
                   APRS_Flush();
                   SEND_CMD();
                   GET_DATA_OR_ACK_FROM_APRS();
                   SHOW_APRS_DATA();
                   fprintf(DEBUG, "Beacon turn on command executed\r\n");
                   DEL_CMD_DATA();               
                   DEL_APRS_DATA();
                   
                   break;
                   
                   case 0x88://Sri lanka Beacon off command
                  
                   APRS_Flush();
                   SEND_CMD();
                   GET_DATA_OR_ACK_FROM_APRS();
                   SHOW_APRS_DATA();
                   fprintf(DEBUG, "Beacon turn off command executed\r\n");//debug
                   DEL_CMD_DATA();
                   
                   break;
                   
                   case 0x69://erase sector
                  
                   APRS_Flush();
                   command_data[3] = 0x00;
                   SEND_CMD();
                   GET_DATA_OR_ACK_FROM_APRS();
                   SHOW_APRS_DATA();
                   fprintf(DEBUG, "Data erase from sectors command executed\r\n");//debug
                   DEL_CMD_DATA();
                   
                   break;
               }
               break;
           }// End of Switch B0~B6
           print_ln();
        }//End of If statement
             
      DEL_CMD_DATA();   
    }//End of While
}
